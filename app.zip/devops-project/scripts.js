let array = [];
let initialArray = []; // Store the initial array for reset

let delay = 50; // Default delay set to 50 milliseconds
let animationSpeed = 5; // Default animation speed in milliseconds

// Function to delay sorting visualization
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// Function to swap elements in the array with animation delay
async function swap(i, j, currentDelay) {
  await sleep(currentDelay);
  let temp = array[i];
  array[i] = array[j];
  array[j] = temp;
  updateBars();
}

// Bubble Sort algorithm with visualization
async function bubbleSort(currentDelay) {
  let n = array.length;
  for (let i = 0; i < n - 1; i++) {
    for (let j = 0; j < n - i - 1; j++) {
      if (array[j] > array[j + 1]) {
        await swap(j, j + 1, currentDelay);
      }
    }
  }
}

// Insertion Sort algorithm with visualization
async function insertionSort(currentDelay) {
  let n = array.length;
  for (let i = 1; i < n; i++) {
    let key = array[i];
    let j = i - 1;
    while (j >= 0 && array[j] > key) {
      array[j + 1] = array[j];
      j--;
      updateBars();
      await sleep(currentDelay);
    }
    array[j + 1] = key;
    updateBars();
    await sleep(currentDelay);
  }
}

// Selection Sort algorithm with visualization
async function selectionSort(currentDelay) {
  let n = array.length;
  for (let i = 0; i < n - 1; i++) {
    let minIndex = i;
    for (let j = i + 1; j < n; j++) {
      if (array[j] < array[minIndex]) {
        minIndex = j;
      }
    }
    await swap(i, minIndex, currentDelay);
  }
}

// Merge Sort algorithm with visualization
async function mergeSort(currentDelay) {
  await mergeSortRecursive(0, array.length - 1, currentDelay);
}

async function mergeSortRecursive(left, right, currentDelay) {
  if (left < right) {
    let mid = Math.floor((left + right) / 2);
    await mergeSortRecursive(left, mid, currentDelay);
    await mergeSortRecursive(mid + 1, right, currentDelay);
    await merge(left, mid, right, currentDelay);
  }
}

async function merge(left, mid, right, currentDelay) {
  let leftArray = array.slice(left, mid + 1);
  let rightArray = array.slice(mid + 1, right + 1);
  let i = 0, j = 0, k = left;

  while (i < leftArray.length && j < rightArray.length) {
    if (leftArray[i] <= rightArray[j]) {
      array[k++] = leftArray[i++];
    } else {
      array[k++] = rightArray[j++];
    }
    await sleep(currentDelay);
    updateBars();
  }

  while (i < leftArray.length) {
    array[k++] = leftArray[i++];
    await sleep(currentDelay);
    updateBars();
  }

  while (j < rightArray.length) {
    array[k++] = rightArray[j++];
    await sleep(currentDelay);
    updateBars();
  }
}

// Quick Sort algorithm with visualization
async function quickSort(low, high, currentDelay) {
  if (low < high) {
    let pi = await partition(low, high, currentDelay);
    await quickSort(low, pi - 1, currentDelay);
    await quickSort(pi + 1, high, currentDelay);
  }
}

async function partition(low, high, currentDelay) {
  let pivot = array[high];
  let i = low - 1;
  for (let j = low; j < high; j++) {
    if (array[j] < pivot) {
      i++;
      await swap(i, j, currentDelay);
    }
  }
  await swap(i + 1, high, currentDelay);
  return i + 1;
}

// Function to update array bars in the DOM
function updateBars() {
  const arrayContainer = document.getElementById('arrayContainer');
  arrayContainer.innerHTML = ''; // Clear previous bars

  array.forEach(value => {
    const bar = document.createElement('div');
    bar.classList.add('array-bar');
    bar.style.height = `${value * 5}px`; // Adjust height based on value
    bar.textContent = value;
    arrayContainer.appendChild(bar);
  });
}

// Function to start sorting based on selected algorithm
async function startSorting() {
  const algorithmSelect = document.getElementById('algorithm');
  const algorithm = algorithmSelect.value;
  const currentDelay = delay;

  switch (algorithm) {
    case 'bubble':
      await bubbleSort(currentDelay);
      break;
    case 'insertion':
      await insertionSort(currentDelay);
      break;
    case 'selection':
      await selectionSort(currentDelay);
      break;
    case 'merge':
      await mergeSort(currentDelay);
      break;
    case 'quick':
      await quickSort(0, array.length - 1, currentDelay);
      break;
    default:
      console.log('Unknown algorithm');
  }
}

// Function to generate array based on user input size
function generateArray() {
  const sizeInput = document.getElementById('size');
  const size = parseInt(sizeInput.value);
  array = []; // Reset array
  initialArray = []; // Reset initial array

  // Validate input size
  if (isNaN(size) || size <= 0) {
    alert('Please enter a valid positive number for array size.');
    return;
  }

  // Prompt user to enter values for the array
  for (let i = 0; i < size; i++) {
    let inputValue = parseInt(prompt(`Enter value ${i + 1} of ${size}:`));
    if (!isNaN(inputValue)) {
      array.push(inputValue);
      initialArray.push(inputValue); // Store initial input values
    } else {
      alert('Invalid input. Please enter a number.');
      return;
    }
  }

  // Update bars in the DOM
  updateBars();
}

// Function to reset the array to its original unsorted form
function resetArray() {
  if (initialArray.length === 0) {
    alert('Please generate an array first.');
    return;
  }

  array = [...initialArray]; // Reset array to initial unsorted form

  // Update bars in the DOM
  updateBars();
}

// Function to change the sorting speed based on the slider value
function changeSpeed(value) {
  delay = parseInt(value);
  document.getElementById('speedLabel').textContent = `${delay} ms`;
}

// Initial array generation on page load
resetArray();
